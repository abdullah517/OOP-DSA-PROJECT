#define _CRT_SECURE_NO_WARNING
#include<Windows.h>
#include<iostream>
#include<string>
#include<vector>
#include<fstream>
using namespace std;

int hour, mins, sec;
int year, month, day;

void settime(int& hour, int& min, int& sec)
{
	SYSTEMTIME t;
	GetSystemTime(&t);
	hour = t.wHour;
	mins = t.wMinute;
	sec = t.wSecond;
}

void set_today_date() {
	SYSTEMTIME tod_dt;
	GetSystemTime(&tod_dt);
	year = tod_dt.wYear;
	month = tod_dt.wMonth;
	day = tod_dt.wDay;
}

void displaytime(int hour, int min, int sec)
{
	cout << hour << ":" << min << ":" << sec << endl;
}

class filehandling;

class passenger
{
	friend class filehandling;
	string name, des, boar, type;
	int seat_no, totalfare = 0;
	string tr_name;
protected:
	string id;
public:
	passenger* next = NULL;
	void setname(string name)
	{
		this->name = name;
	}
	void setid(string id)
	{
		this->id = id;
	}
	void settype(string type)
	{
		this->type = type;
	}
	void setseatno(int seat_no)
	{
		this->seat_no = seat_no;
	}
	void setdes(string des)
	{
		this->des = des;
	}
	void setboar(string boar)
	{
		this->boar = boar;
	}
	void settr_na(string tr_name)
	{
		this->tr_name = tr_name;
	}
	void calculate_totalfare(int noofseats, int fare, int nochil = 0, bool rail_emp = false)
	{
		int c_dis = 0, e_dis = 0;
		if (rail_emp)
			e_dis = fare * 20 / 100;
		if (nochil != 0)
		{
			c_dis = fare * 20 / 100;
			c_dis = nochil * fare;
		}
		totalfare = (fare * noofseats) - c_dis - e_dis;
	}
	void t_display(int noofseats, vector<int>t)
	{
		vector<int>::iterator it;
		cout << "Passenger Name = " << name;
		cout << "\nPassenger CNIC = " << id;
		cout << "\nNo. of Seats Bought = " << noofseats;
		cout << "\nDeparture = " << boar;
		cout << "\nDestination = " << des;
		cout << "\nTotal Fare = " << totalfare;
		cout << "\nTicket type = " << type;
		cout << "\nyour seat number are ";
		for (it = t.begin(); it != t.end(); ++it) {
			cout << *it << " ";
		}
		cout << "\nTicket Bought at = ";
		displaytime(hour, mins, sec);
	}
	string getid()
	{
		return id;
	}
	string getname()
	{
		return name;
	}
	int getseat()
	{
		return seat_no;
	}
};

class store_record : public passenger
{
	store_record* next = NULL;
public:
	int count_m[13] = { 0 };

	int generate_ind(string id)
	{
		int sum = 0, key;
		for (int i = 0; i < id.length(); i++)
			sum = sum + id[i];
		key = sum % 11;
		return key;
	}
	void displayrecord(int m)
	{
		cout << "User's' ID = " << id << endl;
		cout << "\nNo. of travels in month no. " << m << " = " << count_m[m] << " times.\n";
	}
	void insertrec(store_record* record[], string id, int m)
	{
		store_record* ptr = checkinguserexistance(record, id);
		if (ptr != NULL)
			ptr->count_m[m] += 1;
		else
		{
			int key = generate_ind(id);
			store_record* temp = record[key];
			if (temp == NULL)
			{
				record[key] = new store_record;
				record[key]->id = id;
				record[key]->count_m[m] += 1;
			}
			else
			{
				while (temp->next != NULL)
					temp = temp->next;
				temp->next = new store_record;
				temp->next->id = id;
				temp->next->count_m[m] += 1;
			}
		}
	}
	store_record* checkinguserexistance(store_record* record[], string id)
	{
		int key = generate_ind(id);
		if (record[key] == NULL)
			return NULL;
		else
		{
			store_record* temp = record[key];
			while (temp != NULL)
			{
				if (temp->id == id)
					return temp;
				temp = temp->next;
			}
		}
		return NULL;
	}
	void search(store_record* record[], string id, int m)
	{
		store_record* temp = checkinguserexistance(record, id);
		if (temp == NULL)
			cout << "No record of this ID found!!!" << endl;
		else
			temp->displayrecord(m);
	}
};

class Time_D {
public:
	int hr, mt;
	void set_tme() {
		cout << "Enter Departure time:\n";
	a:
		cout << "hour = ";
		cin >> hr;
		if (hr < 1 && hr > 24) { cout << "Invalid hour format\n"; goto a; }
	b:
		cout << "minutes = ";
		if (mt < 1 && mt > 60) { cout << "Invalid minutes format\n"; goto b; }
		cin >> mt;
	}
	void display_tme() {
		cout << "\nDeparture time is " << hr << ":" << mt << endl;
	}
};

class date
{
public:
	int m, d, y;
	void setdate()
	{
		set_today_date();
		cout << "Enter Departure Date:\n";
	a:
		cout << "Month = ";
		cin >> m;
		if (m < 1 && m > 12) { cout << "Invalid month\n"; goto a; }
	b:
		cout << "Day = ";
		cin >> d;
		if (d < 1 && d > 31) { cout << "Invalid day\n"; goto b; }
	c:
		cout << "Year = ";
		cin >> y;
		if (y < year) { cout << "Invalid year\n"; goto c; }
	}
	void displaydate()
	{
		cout << "Date (Month/Day/Year)" << m << " / " << d << " / " << y;
	}
};

class cabin
{
public:
	int getfare()
	{
		return fare;
	}
	int totalseats, fare;
};

class parlorcabin : public cabin
{
public:
	vector<int>arr3;
	int t1;
	void setseats()
	{
		cout << "Enter no of seats for Parlor Class = ";
		cin >> totalseats;
		t1 = totalseats;
	}

	void setfare()
	{
		cout << "Enter fare for parlor class = ";
		cin >> fare;
	}
	void display()
	{
		cout << "Total number of Seats Of Parlor Class are = " << t1;
		cout << "\nSeats left in Parlor Class are = " << totalseats;
		cout << "\nFare of Parlor Class is = " << fare << endl;
	}
};

class economycabin : public cabin
{
public:
	vector<int>arr1;
	int t2;
	void setseats()
	{
		cout << "Enter no of seats for Economy Class = ";
		cin >> totalseats;
		t2 = totalseats;
	}
	void setfare()
	{
		cout << "Enter fare for Economy Class = ";
		cin >> fare;
	}
	void display()
	{
		cout << "Total number of Seats Of Economy Class are = " << t2;
		cout << "\nSeats left in Economy Class are = " << totalseats;
		cout << "\nFare of Economy Class is = " << fare << endl;
	}
};

class businesscabin : public cabin
{
public:
	vector<int>arr2;
	int t3;
	void setseats()
	{
		cout << "Enter no. of seats for Business Class = ";
		cin >> totalseats;
		t3 = totalseats;
	}
	void setfare()
	{
		cout << "Enter fare for Business Class = ";
		cin >> fare;
	}
	void display()
	{
		cout << "Total number of Seats Of Buisness Class are = " << t3;
		cout << "\nSeats left in Buisness Class are = " << totalseats;
		cout << "\nFare of Buisness Class is = " << fare << endl;
	}
};

class admin;

class train
{
	friend class filehandling;
	friend class admin;
	int train_no;
	string train_name;
	string boarding_point;
	string destination_point;
	passenger* catg[3] = { NULL };
	parlorcabin* p;
	businesscabin* b;
	economycabin* e;
	date d;
	Time_D t1;
	train* next = NULL;
public:
	void setname()
	{
		cin.ignore();
		cout << "Enter Train Name = ";
		getline(cin, train_name);
	}
	void setno()
	{
		cout << "Enter Train No. = ";
		cin >> train_no;
	}
	void set_boarding_point()
	{
		cout << "Enter Boarding Point = ";
		cin >> boarding_point;
	}
	void set_destination_point()
	{
		cout << "Enter Destination Point = ";
		cin.ignore();
		cin >> destination_point;
	}
	void display()
	{
		cout << "\nTrain Name = " << train_name << endl;
		cout << "Train Number = " << train_no << endl;
		cout << "Boarding Point = " << boarding_point << endl;
		cout << "Destination Point = " << destination_point << endl;
	}
	void readtraindata()
	{
		setname();
		setno();
		set_boarding_point();
		set_destination_point();
		p->setseats();
		p->setfare();
		b->setseats();
		b->setfare();
		e->setseats();
		e->setfare();
		d.setdate();
		t1.set_tme();
	}
	void displaytraindata()
	{
		display();
		p->display();
		b->display();
		e->display();
		d.displaydate();
		t1.display_tme();
	}

	void store_train_in_file() {
		ofstream myfile;
		myfile.open("train.txt", ios::out | ios::app);
		myfile << train_no << " " << train_name << " " << boarding_point << " " << destination_point
			<< " " << b->totalseats << " " << b->fare << " " << p->totalseats << " " << p->fare <<
			" " << e->totalseats << " " << e->fare << " " << d.m << " " << d.d << " " << d.y << " "
			<< t1.hr << " " << t1.mt << endl;
		myfile.close();
	}
};

void main_menu(admin& b);
class admin
{
	friend class filehandling;
	int count_t[13] = { 0 };
	int m;
	string b_p, password = "admin", u_id;
	store_record* record[10] = { NULL };
	store_record s;
	train* trn = NULL;
public:

	void settrn(train*& t)
	{
		trn = t;
	}

	void recordoftick(int m, int n) {
		count_t[m] += n;
	}

	void displaytick(int m) {
		cout << "\nIn this month no of selling tickets is " << count_t[m] << "\n\n";
	}

	void Admin(admin& b)
	{
		int y, mon; string name; train* ptr;
		while (1)
		{
			cout << "\n_ADMINISTRATOR MENU_\n\n";
			cout << "1. Create A Detailed Database (ADD new train/trains)\n2. Update Train Record\n3. Delete Train Record\n4. Display Train Details\n5. Display Passenger Details\n6. Display monthly record of a specific passenger\n7. display monthly record of selling tickets\n8. Search specific train\n9. Return to main menu\n";
			cout << "Enter = ";
			cin >> y;
			switch (y)
			{
			case 1:

				data_base(b);
				break;
			case 2:

				cout << "Enter the name of train = ";
				cin.ignore();
				getline(cin, name);
				updatetrainrecord(name);
				break;

			case 3:

				cout << "Enter the name of train = ";
				cin.ignore();
				getline(cin, name);
				deletetrain(name);
				break;

			case 4:

				display_train();
				break;


			case 5:

				displaypassengerdetails();
				break;

			case 6:

				cout << "Enter User ID = ";
				cin >> u_id;
				cout << "Enter a month no. = ";
				cin >> m;
				s.search(record, u_id, m);
				break;

			case 7:
				cout << "Enter the month\n\n";
				cin >> mon;
				displaytick(mon);
				break;
			case 8:
			p:
				cout << "Enter the name of train = ";
				cin >> name;
				ptr = searchtrain(name);
				if (ptr == NULL) {
					cout << "NO train found of this name.Try again\n"; goto p;
				}
				else
					ptr->displaytraindata();
				break;
			case 9:

				main_menu(b);

			}
		}
	}
	void showpass(passenger* p)
	{
		int count = 0;
		if (p == NULL)
			cout << "No passengers found in this class!!!\n";
		else
		{
			while (p != NULL)
			{
				if (p->next == NULL)
				{
					cout << "passenger name is " << p->getname();
					cout << "  passenger id is " << p->getid();
					cout << "  his total no of seats is " << count + 1 << endl;
					break;
				}

				if (p->getid().compare(p->next->getid()) == 0)
					count++;
				else
				{
					cout << "passenger name is " << p->getname();
					cout << "  passenger id is " << p->getid();
					cout << "  his total no of seats is " << count + 1 << endl;
					count = 0;
				}
				p = p->next;
			}
		}
	}

	void displaypassengerdetails()
	{
		string name;
		train* temp;
		int choice;
		cout << "Enter name of train to search the passengers = ";
		cin.ignore();
		getline(cin, name);
		temp = searchtrain(name);
		if (temp == NULL)
			cout << "No train found of this name\n";
		else
		{
			cout << "In which class you want to find the passenger details?\n";
			cout << "\nPress 1. for economy.";
			cout << "\nPress 2. for business.";
			cout << "\nPress 3. for parlor.";
			cin >> choice;
			switch (choice)
			{
			case 1:
				showpass(temp->catg[0]);
				break;
			case 2:
				showpass(temp->catg[1]);
				break;
			case 3:
				showpass(temp->catg[2]);
				break;
			}
		}
	}
	void data_base(admin& b)
	{
		char n;
		cout << "\nInserting train data:\n\n";
		inserttrain();
		while (true)
		{
			cout << "Do you want to Enter Data again\t(y/n) = \t";
		x:
			cin >> n;
			if (n == 'y')
				inserttrain();
			else if (n == 'n')
				Admin(b);
			else
			{
				cout << "Wrong keyword entered. Please Re-enter the correct option\n";
				goto x;
			}
		}
	}
	void matching_pass(admin& b)
	{
	b:
		cout << "Enter Password = ";
		cin >> b_p;
		if (b_p == password)
			b.Admin(b);
		else
		{
			cout << "Wrong password entered! Try again\n";
			goto b;
		}
	}

	void inserttrain()
	{
		train* ptr = new train;
		ptr->p = new parlorcabin;
		ptr->e = new economycabin;
		ptr->b = new businesscabin;
		ptr->readtraindata();
		ptr->store_train_in_file();
		if (trn == NULL)
			trn = ptr;
		else
		{
			train* p = trn;
			while (p->next != NULL)
				p = p->next;
			p->next = ptr;
		}
	}
	void display_train()
	{
		train* ptr = trn;
		int x = 0;
		if (ptr == NULL)
			cout << "Train Record Is Empty!!!";
		else
		{
			set_today_date();
			while (ptr != NULL)
			{
				if (ptr->d.d >= day && ptr->d.m >= month && ptr->d.y >= year) {
					ptr->displaytraindata();
					cout << endl;
					ptr = ptr->next;
					x = 1;
				}
				else
					ptr = ptr->next;
			}
			if (x == 0)
				cout << "no upcoming trains found\n";
		}
	}
	train* searchtrain(string name)
	{
		train* temp = trn;
		if (temp == NULL)
			return temp;
		else
		{
			while (temp != NULL)
			{
				if (temp->train_name.compare(name) == 0)
					return temp;
				temp = temp->next;
			}
		}
		return temp;
	}
	train* searchprevioustrain(string name)
	{
		train* temp1 = trn->next;
		train* temp2 = trn;
		while (temp1 != NULL)
		{
			if (temp1->train_name.compare(name) == 0)
				return temp2;
			temp2 = temp1;
			temp1 = temp1->next;
		}
		return temp1;
	}

	void copystring(char name[], string data) {
		int i;
		for (i = 0; i < data.length(); i++) {
			name[i] = data[i];
		}
		name[i] = '\0';
	}

	void changeorderoffile(train*dtr) {
		char newname[15],oldname[15]; ifstream myfile; string data;
		while (dtr != NULL) {
			data=generate_name(dtr);
			copystring(oldname, data);
			myfile.open(data);
			if (myfile) {
				data=generate_name(dtr, 1);
				copystring(newname,data);
				myfile.close();
				if (rename(oldname, newname) == 0);
			}
			dtr = dtr->next;
		}
	}

	void deletetrain(string name)
	{
		string data; char fname[15]; ifstream myfile1;
		if (trn == NULL)
			cout << "No train found!!!";
		else
		{
			if (trn->train_name.compare(name) == 0)
			{
				data = generate_name(trn);
				myfile1.open(data);
				if (myfile1) {
					myfile1.close();
					copystring(fname, data);
					remove(fname);
				}
				changeorderoffile(trn->next);
				train* ptr = trn;
				trn = trn->next;
				delete ptr->p;
				delete ptr->b;
				delete ptr->e;
				delete ptr;
				updatetrainrecordinfile();
			}
			else
			{
				train* t2 = searchprevioustrain(name);
				if (t2 != NULL)
				{
					train* t1 = t2->next;
					data = generate_name(t1);
					copystring(fname, data);
					remove(fname);
					changeorderoffile(t1->next);
					t2->next = t1->next;
					delete t1->p;
					delete t1->b;
					delete t1->e;
					delete t1;
					updatetrainrecordinfile();
				}
				else
					cout << "train not found" << endl;
			}
		}
	}

	void updatetrainrecordinfile() {
		ofstream myfile;
		myfile.open("train1.txt");
		train* temp = trn;
		while (temp != NULL) {
			myfile << temp->train_no << " " << temp->train_name << " " << temp->boarding_point << " " << temp->destination_point
				<< " " << temp->b->t3 << " " << temp->b->fare << " " << temp->p->t1 << " " << temp->p->fare <<
				" " << temp->e->t2 << " " << temp->e->fare << " " << temp->d.m << " " << temp->d.d << " " << temp->d.y << " "
				<< temp->t1.hr << " " << temp->t1.mt << endl;
			temp = temp->next;
		}
		myfile.close();
		remove("train.txt");
		if (rename("train1.txt", "train.txt") == 0);
		return;
	}

	void updatetrainrecord(string name)
	{
		train* temp;
		int choice; string data; ifstream myfile1; char fname[15];
		temp = searchtrain(name);
		if (temp == NULL)
		{
			cout << "\nNo train found!!!" << endl;
			return;
		}
		else
		{
			cout << "\nWhich record of train you want to update\n";
			cout << "press 1. for Name\n";
			cout << "press 2. for Number\n";
			cout << "press 3. for destination point\n";
			cout << "press 4. for boarding point\n";
			cout << "press 5. for Date\n";
			cout << "press 6. for Seats\n";
			cout << "press 7. for Fare\n";
			cout << "press 8. for time\n";
			cout << "press 9. to update train for next travel\n";
			cin >> choice;
			switch (choice)
			{
			case 1:
				temp->setname();
				updatetrainrecordinfile();
				break;
			case 2:
				temp->setno();
				updatetrainrecordinfile();
				break;
			case 3:
				temp->set_destination_point();
				updatetrainrecordinfile();
				break;
			case 4:
				temp->set_boarding_point();
				updatetrainrecordinfile();
				break;
			case 5:
				temp->d.setdate();
				updatetrainrecordinfile();
				break;
			case 6:
				cout << "\nPress 1 for parlor class seats." << endl;
				cout << "Press 2 for business class seats." << endl;
				cout << "Press 3 for economy class seats." << endl;
				cin >> choice;
				switch (choice)
				{
				case 1:
					temp->p->setseats();
					updatetrainrecordinfile();
					break;
				case 2:
					temp->b->setseats();
					updatetrainrecordinfile();
					break;
				case 3:
					temp->e->setseats();
					updatetrainrecordinfile();
					break;
				}
				break;
			case 7:
				cout << "\nPress 1 for parlor class fare." << endl;
				cout << "Press 2 for business class fare." << endl;
				cout << "Press 3 for economy class fare." << endl;
				cin >> choice;
				switch (choice)
				{
				case 1:
					temp->p->setfare();
					updatetrainrecordinfile();
					break;
				case 2:
					temp->b->setfare();
					updatetrainrecordinfile();
					break;
				case 3:
					temp->e->setfare();
					updatetrainrecordinfile();
					break;
				}
				break;
			case 8:
				temp->t1.set_tme();
				updatetrainrecordinfile();
				break;
			case 9:
				temp->set_boarding_point();
				temp->set_destination_point();
				temp->d.setdate();
				temp->b->setseats();
				temp->p->setseats();
				temp->e->setseats();
				temp->t1.set_tme();
				temp->catg[0] = NULL;
				temp->catg[1] = NULL;
				temp->catg[2] = NULL;
				updatetrainrecordinfile();
				data = generate_name(temp);
				myfile1.open(data);
				if (myfile1) {
					myfile1.close();
					copystring(fname, data);
					remove(fname);
				}
				break;
			}
		}
	}
	bool isgrea(passenger* p, int s) {
		while (p != NULL) {
			if (p->getseat() >= s) {
				return true;
			}
			p = p->next;
		}
		return false;
	}

	string generate_name(train* gtr,int t=0) {
		train* dtr = trn; int c = 0;
		string x = "train", y = "pass", z, s = ".txt";
		while (dtr != gtr->next) {
			c++;
			dtr = dtr->next;
		}
		c -= t;
		z = to_string(c);
		x = x + z + y + s;
		return x;
	}
    
	void insertuserinfile(train*dtr,string name,string id,int seats,string tpy) {
		string filename = generate_name(dtr);
		ofstream myfile1,myfile2;
		myfile1.open(filename,ios::out | ios::app);
		myfile2.open("record.txt",ios::out | ios::app);
		myfile1 << name << " " << id << " " << seats <<" "<<tpy << endl;
		myfile2 << id << " " << dtr->d.m << " " << seats << endl;
		myfile1.close();
		myfile2.close();
	}

	void addineconomy(train* tr, int uns, string boar, string des, int month)
	{
		vector<int>t;
		int key = 0, no = 0, count = 1;
		string id, name; passenger* temp;
		bool emp = false;
		char c, x;
		cout << "Enter the Following Details:" << endl;
		cout << "\nEnter your name = ";
		cin.ignore();
		getline(cin, name);
		cout << "Enter your id = ";
		getline(cin, id);
		insertuserinfile(tr, name, id, uns,"economy");
		recordoftick(m, uns);
		s.insertrec(record, id, month);
	t:
		cout << "\nIs any of your ticket holder a minor? (y/n) = ";
		cin >> x;
		if (x == 'y')
		{
			cout << "Enter no. of minors";
			cin >> no;
		}
		else if (x != 'y' && x != 'n')
		{
			cout << "Incorrect command!!!\nPlease Re-Enter\n";
			goto t;
		}
	em:
		cout << "Are you a Railway Employee? (y/n) = ";
		cin >> c;
		if (c == 'y')
			emp = true;
		else if (c != 'y' && c != 'n')
		{
			cout << "Incorrect command!!!\nPlease Re-Enter\n";
			goto em;
		}
		for (int i = 1; i <= uns; i++)
		{
			passenger* ptr = new passenger;
			ptr->setname(name);
			ptr->setid(id);
			ptr->settype("economy");
			ptr->setdes(des);
			ptr->setboar(boar);
			if (tr->catg[key] == NULL)
			{
				tr->catg[key] = ptr;
				tr->catg[key]->setseatno(count);
				t.push_back(count);

				if (uns == 1) {
					tr->catg[key]->calculate_totalfare(uns, tr->e->getfare(), no, emp);
					settime(hour, mins, sec);
					cout << "\n\nticket purchased successfully\n\n";
					cout << "\n\nticket details are as follows\n\n";
					tr->catg[key]->t_display(uns, t);
					tr->t1.display_tme();
				}
			}
			else
			{
				temp = tr->catg[key];
				while (temp->next != NULL)
				{
					temp = temp->next;
					count++;
				}
				count++;
				temp->next = ptr;
				temp = temp->next;
				if (isgrea(tr->catg[key], tr->e->t2)) {
					count = tr->e->arr1.front();
					temp->setseatno(count);
					t.push_back(count);
					count = 1;
					vector<int>::iterator it = tr->e->arr1.begin();
					tr->e->arr1.erase(it);
				}
				else {
					temp->setseatno(count);
					t.push_back(count);
					count = 1;
				}

				if (i == uns) {
					temp->calculate_totalfare(uns, tr->e->getfare(), no, emp);
					settime(hour, mins, sec);
					cout << "\n\ntickets purchased successfully\n\n";
					cout << "\n\nticket details are as follows\n\n";
					temp->t_display(uns, t);
					tr->t1.display_tme();
				}
			}
		}
	}
	void addinbusiness(train* tr, int uns, string boar, string des, int month)
	{
		vector<int>t;
		int key = 1, no = 0, count = 1;
		string id, name; passenger* temp;
		bool emp = false;
		char c, x;
		cout << "Enter the Following Details:" << endl;
		cout << "\nEnter your name = ";
		cin.ignore();
		getline(cin, name);
		cout << "Enter your id = ";
		getline(cin, id);
		insertuserinfile(tr, name, id, uns,"business");
		recordoftick(m, uns);
		s.insertrec(record, id, month);
	t:
		cout << "\nIs any of your ticket holder a minor? (y/n) = ";
		cin >> x;
		if (x == 'y')
		{
			cout << "Enter no. of minors";
			cin >> no;
		}
		else if (x != 'y' && x != 'n')
		{
			cout << "Incorrect command!!!\nPlease Re-Enter\n";
			goto t;
		}
	e:
		cout << "Are you a Railway Employee? (y/n) = ";
		cin >> c;
		if (c == 'y')
			emp = true;
		else if (c != 'y' && c != 'n')
		{
			cout << "Incorrect command!!!\nPlease Re-Enter\n";
			goto e;
		}
		for (int i = 1; i <= uns; i++)
		{
			passenger* ptr = new passenger;
			ptr->setname(name);
			ptr->setid(id);
			ptr->settype("business");
			ptr->setdes(des);
			ptr->setboar(boar);
			if (tr->catg[key] == NULL)
			{
				tr->catg[key] = ptr;
				tr->catg[key]->setseatno(count);
				t.push_back(count);

				if (uns == 1) {
					tr->catg[key]->calculate_totalfare(uns, tr->b->getfare(), no, emp);
					settime(hour, mins, sec);
					cout << "\n\nticket purchased successfully\n\n";
					cout << "\n\nticket details are as follows\n\n";
					tr->catg[key]->t_display(uns, t);
					tr->t1.display_tme();
				}
			}
			else
			{
				temp = tr->catg[key];
				while (temp->next != NULL)
				{
					temp = temp->next;
					count++;
				}
				temp->next = ptr;
				temp = temp->next;
				count++;
				if (isgrea(tr->catg[key], tr->b->t3)) {
					count = tr->b->arr2.front();
					temp->setseatno(count);
					t.push_back(count);
					count = 1;
					vector<int>::iterator it = tr->b->arr2.begin();
					tr->b->arr2.erase(it);
				}
				else {
					t.push_back(count);
					temp->setseatno(count);
					count = 1;
				}

				if (i == uns) {
					temp->calculate_totalfare(uns, tr->b->getfare(), no, emp);
					settime(hour, mins, sec);
					cout << "\n\ntickets purchased successfully\n\n";
					cout << "\n\nticket details are as follows\n\n";
					temp->t_display(uns, t);
					tr->t1.display_tme();
				}
			}
		}
	}
	void addinparlor(train* tr, int uns, string boar, string des, int month)
	{
		vector<int>t;
		int key = 2, no = 0, count = 1;
		string id, name; passenger* temp;
		bool emp = false;
		char c, x;
		cout << "Enter the Following Details:" << endl;
		cout << "\nEnter your name = ";
		cin.ignore();
		getline(cin, name);
		cout << "Enter your id = ";
		getline(cin, id);
		insertuserinfile(tr, name, id, uns,"parlor");
		recordoftick(m, uns);
		s.insertrec(record, id, month);
	t:
		cout << "\nIs any of your ticket holder a minor? (y/n) = ";
		cin >> x;
		if (x == 'y')
		{
			cout << "Enter no. of minors";
			cin >> no;
		}
		else if (x != 'y' && x != 'n')
		{
			cout << "Incorrect command!!!\nPlease Re-Enter\n";
			goto t;
		}
	e:
		cout << "Are you a Railway Employee? (y/n) = ";
		cin >> c;
		if (c == 'y')
			emp = true;
		else if (c != 'y' && c != 'n')
		{
			cout << "Incorrect command!!!\nPlease Re-Enter\n";
			goto e;
		}
		for (int i = 1; i <= uns; i++)
		{
			passenger* ptr = new passenger;
			ptr->setname(name);
			ptr->setid(id);
			ptr->settype("parlor");
			ptr->setdes(des);
			ptr->setboar(boar);
			if (tr->catg[key] == NULL)
			{
				tr->catg[key] = ptr;
				tr->catg[key]->setseatno(count);
				t.push_back(count);

				if (uns == 1) {
					tr->catg[key]->calculate_totalfare(uns, tr->p->getfare(), no, emp);
					settime(hour, mins, sec);
					cout << "\n\nticket purchased successfully\n\n";
					cout << "\n\nticket details are as follows\n\n";
					tr->catg[key]->t_display(uns, t);
					tr->t1.display_tme();
				}
			}
			else
			{
				temp = tr->catg[key];
				while (temp->next != NULL)
				{
					temp = temp->next;
					count++;
				}
				count++;
				temp->next = ptr;
				temp = temp->next;
				if (isgrea(tr->catg[key], tr->p->t1)) {
					count = tr->p->arr3.front();
					t.push_back(count);
					temp->setseatno(count);
					count = 1;
					vector<int>::iterator it = tr->p->arr3.begin();
					tr->p->arr3.erase(it);
				}
				else {
					temp->setseatno(count);
					t.push_back(count);
					count = 1;
				}

				if (i == uns) {
					temp->calculate_totalfare(uns, tr->p->getfare(), no, emp);
					settime(hour, mins, sec);
					cout << "\n\ntickets purchased successfully\n\n";
					cout << "\n\nticket details are as follows\n\n";
					temp->t_display(uns, t);
					tr->t1.display_tme();
				}
			}
		}
	}
	void sellticket(train* tr, int m, string boar, string des) {
		int choice, no;
		cout << "\nChoose a Class:\n";
		cout << "Enter 1. for economy class\n";
		cout << "Enter 2. for business class\n";
		cout << "Enter 3. for parlor class\n";
		cout << "Enter = ";
		cin >> choice;
		cout << "Enter the amount of tickets you want to purchase = ";
		cin >> no;
		switch (choice)
		{
		case 1:
			if (tr->e->totalseats >= no)
			{
				tr->e->totalseats -= no;
				addineconomy(tr, no, boar, des, m);
			}
			else
				cout << "Sorry, No seats available as per your request!!!\n";
			break;
		case 2:
			if (tr->b->totalseats >= no)
			{
				tr->b->totalseats -= no;
				addinbusiness(tr, no, boar, des, m);
			}
			else
				cout << "Sorry, No seats available as per your request\n";
			break;
		case 3:
			if (tr->p->totalseats >= no)
			{
				tr->p->totalseats -= no;
				addinparlor(tr, no, boar, des, m);
			}
			else
				cout << "Sorry, No seats available as per your request\n";
			break;
		}
	}

	int finduser(passenger*& p, string id) {
		int count = 0;
		passenger* temp;
		if (p == NULL) {
			return count;
		}
		else {
			temp = p;
			while (temp != NULL) {
				if (temp->getid() == id) {
					count++;
				}
				temp = temp->next;
			}
		}
		return count;
	}

	void usertickdel(passenger*& p, string id, vector<int>& ptr)
	{
		passenger* t1;
		passenger* t2;
		if (p->getid() == id)
		{
			passenger* temp = p;
			ptr.push_back(p->getseat());
			p = p->next;
			delete temp;
		}
		else
		{
			t1 = p->next;
			t2 = p;
			while (t1 != NULL)
			{
				if (t1->getid() == id)
				{
					passenger* temp = t1;
					t2->next = t1->next;
					ptr.push_back(t1->getseat());
					delete temp;
					return;
				}
				t2 = t1;
				t1 = t1->next;
			}
		}
	}

	void copyrecinfile(passenger* p,ifstream &myfile1,string data,string type,ofstream&myfile2) {
		int s = 0;
		myfile2.open("temporary.txt",ios::out|ios::app);
		while (p != NULL)
		{
			if (p->next == NULL)
			{
				myfile2 << p->getname() << " " << p->getid() << " " << s + 1 << " " << type << endl;
				break;
			}

			if (p->getid().compare(p->next->getid()) == 0)
				s++;
			else
			{
				myfile2 << p->getname() << " " << p->getid() << " " << s + 1 << " " << type << endl;
				s = 0;
			}
			p = p->next;
		}
		myfile2.close();
	}

	void updpsgrecinfile(train*dtr){
		ifstream myfile1; string data; char fname[15]; ofstream myfile2;
		data = generate_name(dtr);
		myfile1.open(data);
		if (myfile1) {
			myfile1.close();
			copystring(fname, data);
			copyrecinfile(dtr->catg[0],myfile1,data,"economy",myfile2);
			copyrecinfile(dtr->catg[1], myfile1, data,"business", myfile2);
			copyrecinfile(dtr->catg[2], myfile1, data,"parlor", myfile2);
			remove(fname);
			if (rename("temporary.txt", fname) == 0);
		}
	}

	void cancelticket()
	{
		int choice, no, count;
		train* tr;
		string name, id;
		passenger* ptr;
	c:
		cout << "Enter Name of the Train = ";
		cin.ignore();
		getline(cin, name);
		tr = searchtrain(name);
		if (tr == NULL)
		{
			cout << "Enter again" << endl;
			goto c;
		}
		else
		{
			cout << "\nWhich type of ticket you bought?" << endl;
			cout << "Press 1. for economy class" << endl;
			cout << "Press 2. for business class" << endl;
			cout << "Press 3. for parlor class" << endl;
			cin >> choice;
			switch (choice)
			{
			case 1:
			x:
				cout << "Enter your ID = ";
				cin >> id;
				count = finduser(tr->catg[0], id);
				if (count == 0) {
					cout << "no user found!!!" << endl;
					goto x;
				}
				else {
					for (int i = 1; i <= count; i++) {
						usertickdel(tr->catg[0], id, tr->e->arr1);
					}
					cout << "\nYour tickets cancelled successfully\n";
					tr->e->totalseats += count;
					updpsgrecinfile(tr);
				}
				break;
			case 2:
			y:
				cout << "Enter your ID = ";
				cin >> id;
				count = finduser(tr->catg[1], id);
				if (count == 0) {
					cout << "no user found!!!" << endl;
					goto y;
				}
				else {
					for (int i = 1; i <= count; i++) {
						usertickdel(tr->catg[1], id, tr->b->arr2);
					}
					cout << "\nYour tickets cancelled successfully\n";
					tr->b->totalseats += count;
					updpsgrecinfile(tr);
				}
				break;

			case 3:

			z:
				cout << "Enter your ID = ";
				cin >> id;
				count = finduser(tr->catg[2], id);
				if (count == 0) {
					cout << "no user found!!!" << endl;
					goto z;
				}
				else {
					for (int i = 1; i <= count; i++) {
						usertickdel(tr->catg[2], id, tr->p->arr3);
					}
					cout << "\nYour tickets cancelled successfully\n";
					tr->p->totalseats += count;
					updpsgrecinfile(tr);
				}
				break;
			}
		}
	}
	void getinfo()
	{
		string from, to, name;
		train* s[5];
		int m, i, d, y, ind = 0; bool f = false;
		train* temp = trn;
		cout << "\nEnter your destination:" << endl;
		cout << "From:" << endl;
		cin.ignore();
		getline(cin, from);
		cout << "To" << endl;
		getline(cin, to);
		cout << "Enter Departure Date:\n";
		cout << "Month = ";
		cin >> m;
		cout << "Day = ";
		cin >> d;
		cout << "Year = ";
		cin >> y;
		set_today_date();
		while (temp != NULL)
		{
			if (temp->boarding_point.compare(from) == 0 && temp->destination_point.compare(to) == 0 && temp->d.m == m &&
				temp->d.d == d && temp->d.y == y && m >= month && y >= year && d >= day)
			{
				temp->displaytraindata();
				cout << "\n\n";
				f = true;
				s[ind] = temp;
				ind++;
			}
			temp = temp->next;
		}
		if (f == false)
			cout << "No train available at this time!!!\n";
		else {
			cout << "\n\nSelect train from above options by entering the train name\n";
		c:
			cin.ignore();
			getline(cin, name);
			for (i = 0; i < ind; i++)
			{
				if (s[i]->train_name == name)
					break;
				else if (i == ind - 1)
				{
					cout << "You entered wrong name entered again" << endl;
					goto c;
				}
			}
			sellticket(s[i], m, from, to);
		}
	}
	void user_mode(admin& b)
	{
		while (1)
		{
			int n;
			cout << "\n__USER MODE__" << endl;
			cout << "1. Book Ticket\n2. Cancel Ticket\n3. Return To Main Menu" << endl << endl;
			cout << "Enter = ";
			cin >> n;
			switch (n)
			{
			case 1:
			{
				b.getinfo();
				break;
			}
			case 2:
			{
				b.cancelticket();
				break;
			}
			case 3:
			{
				main_menu(b);
				break;
			}
			}
		}
	}
};

void main_menu(admin& b)
{
	int choice;
	cout << "_MAIN MENU_" << endl << endl;
	cout << "1. Admin Mode\n2. User Mode\n3. Exit \n";
	cout << "Enter = ";
	cin >> choice;
	switch (choice)
	{
	case 1:
	{
		system("cls");
		b.matching_pass(b);
		break;
	}
	case 2:
	{
		system("cls");
		b.user_mode(b);
		break;
	}
	case 3:
	{
		exit(0);
	}
	}
}

void startpro()
{
	int x;
	cout << endl << endl;
	cout << "\t\t\t\t\tWelcome To Railway Reservation Sysytem Project" << endl << endl;
	cout << "\n\n\tFALL 2020 BSCS" << endl << "\tGroup 3" << endl << "\tAbdullah Shahzad (010)" << endl << "\tDanial Khalid (046)" << endl << "\tMusab Rizwan (053)" << endl << endl << endl;
	cout << "\tPress any key to continue!!! ";
	cin >> x;
	system("cls");
}

class filehandling {

public:

	void readdataoftrain(admin&b,train*& temp)
	{
		ifstream myfile; train* ptr,*dtr=NULL;
		myfile.open("train.txt");
		while (myfile) {
			ptr = new train;
			ptr->p = new parlorcabin;
			ptr->e = new economycabin;
			ptr->b = new businesscabin;
			if (temp == NULL)
				temp = ptr;
			else
			{
				dtr = temp;
				while (dtr->next != NULL)
					dtr = dtr->next;
				    dtr->next = ptr;
			}
			myfile >> ptr->train_no >> ptr->train_name >> ptr->boarding_point >> ptr->destination_point >> ptr->b->totalseats >>
				ptr->b->fare >> ptr->p->totalseats >> ptr->p->fare >> ptr->e->totalseats >> ptr->e->fare >>
				ptr->d.m >> ptr->d.d >> ptr->d.y >> ptr->t1.hr >> ptr->t1.mt;
			ptr->p->t1 = ptr->p->totalseats;
			ptr->e->t2 = ptr->e->totalseats;
			ptr->b->t3 = ptr->b->totalseats;

			if (myfile.eof()) {
				dtr->next = NULL;
				delete ptr;
			}
		}
		myfile.close();
	}

	void save(train*&dtr,int ind,string name,string id,int seats) {
		passenger* psg, * ptg;
		for (int i = 1; i <= seats; i++) {
			psg = new passenger;
			psg->setname(name); psg->setid(id);
			if (dtr->catg[ind] == NULL) {
				dtr->catg[ind] = psg;
			}
			else {
				ptg = dtr->catg[ind];
				while (ptg->next != NULL)
					ptg = ptg->next;
				ptg->next = psg;
			}
		}
	}

	void read_passengers(admin&b) {
		train* dtr = b.trn;string fname; ifstream dfile; passenger* psg,*ptg;
		string name, id, type; int seats;
		while (dtr != NULL) {
			fname=b.generate_name(dtr);
			dfile.open(fname);
			if (dfile) {
			while (dfile) {
				dfile >> name >> id >> seats >> type;
				
				if (type == "economy") {
					dtr->e->totalseats -= seats;
					save(dtr, 0, name, id, seats);
				}
				else if (type == "business") {
					dtr->b->totalseats -= seats;
					save(dtr, 1, name, id, seats);
				}
				else if (type == "parlor") {
					dtr->p->totalseats -= seats;
					save(dtr, 2, name, id, seats);
				}
			 }
			dfile.close();
			}
			dtr = dtr->next;
		}
	}

	void readrecord(admin&b) {
		int mon, ts; string id; ifstream myfile1;
		myfile1.open("record.txt");
		if (myfile1) {
			while (myfile1) {
				myfile1 >> id >> mon >> ts;
				if (id != "") {
					b.s.insertrec(b.record,id,mon);
					b.recordoftick(mon,ts);
				}
			}
		}
	}
};

int main()
{
	admin b;
	system("color 3");
	startpro();
	filehandling f;
	train* temp = NULL;
	f.readdataoftrain(b ,temp);
	b.settrn(temp);
	f.read_passengers(b);
	f.readrecord(b);
	main_menu(b);
	system("pause");
}